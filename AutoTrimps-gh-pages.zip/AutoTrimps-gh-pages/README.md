# AutoTrimps - Zek Fork

## Discussion / Discord Channel
<a href="https://discord.gg/Ztcnfjr"><img src="https://png.icons8.com/color/180/discord-new-logo.png" width=48></a>
Discord is a chat program. Come to talk about AutoTrimps, for help, or suggestions for new features : https://discord.gg/Ztcnfjr

## Current Version (full changes below) - Ongoing Development!
- Zek Fork. All changes made by Zek using GenBTC as base. Currently up-to-date as of 06/2019.

## Script Installation

Step 1: Install TamperMonkey

https://www.tampermonkey.net/

Step 2: 

Click this link: https://github.com/Zorn192/AutoTrimps/raw/gh-pages/.user.js

Step 3: 

Configure settings. Will NOT work as intended with default settings. 

## Equipment && Upgrade's colour explaination:

White - Upgrade is not available

Yellow - Upgrade is not affordable

Orange - Upgrade is affordable, but will lower stats

Red - Will buy next
